<?php $__env->startSection('title'); ?> 
User Feedback Summary
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('feedback.layouts.partials.passwordchecker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="modal__content">            
    <h4 class="text-center">User Feedback by <?php echo e($user->name); ?></h4>
    <div class="alert alert-success">
        Here's a summary:
    </div>
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Fields</th>
                            <th>Responses</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: small;">
                        <tr>
                            <td>Name:</td>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <td>Email Address:</td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <?php if($user->phone): ?>
                        <tr>
                            <td>Phone:</td>
                            <td><?php echo e($user->phone); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $showResponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showResponses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($showResponses->form_question->question); ?>:</td>
                            <td><?php echo e($showResponses->response); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a href="<?php echo e(route('responses.index')); ?>" class="btn btn-primary">&laquo; Back</a>
        </div>
    </div>
    <?php echo $__env->make('feedback.layouts.partials.adminmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('feedback.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\EkizoneApps\CustomerFeedBackSystem\resources\views/feedback/admin/show.blade.php ENDPATH**/ ?>