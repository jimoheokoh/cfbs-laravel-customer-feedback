<?php $__env->startSection('title'); ?> 
User Feedback Summary
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<div class="modal__content">            
    <h2>Your Response</h2>
    <div class="alert alert-success">
        Your response has been recorded. Thank you! Here's a summary:
    </div>
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Fields</th>
                            <th>Responses</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: small;">
                        <tr>
                            <td>Name:</td>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <td>Email Address:</td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <?php if($user->phone): ?>
                        <tr>
                            <td>Phone:</td>
                            <td><?php echo e($user->phone); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($response->form_question->question); ?>:</td>
                            <td><?php echo e($response->response); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div> <!-- END: .modal__content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('feedback.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\EkizoneApps\CustomerFeedBackSystem\resources\views/feedback/summary.blade.php ENDPATH**/ ?>