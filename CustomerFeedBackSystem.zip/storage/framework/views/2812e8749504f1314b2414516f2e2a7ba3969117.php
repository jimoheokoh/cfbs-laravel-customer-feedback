<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('f1/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('f1/css/f1.css')); ?>">
    <title>Customer Feedback Summary</title>
</head>
<body>
    <div class="modal">
        <div class="modal__container">
        <div class="modal__featured">
            <svg class="nc-icon glyph" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32">
                <g><path fill="#ffffff" d="M1.293,15.293L11,5.586L12.414,7l-8,8H31v2H4.414l8,8L11,26.414l-9.707-9.707 C0.902,16.316,0.902,15.684,1.293,15.293z"></path> </g></svg>
            </button>
            <div class="modal__circle"></div>
           <!-- featured image here -->
        </div>
        <div class="modal__content">            
           <h2>User Response</h2>
            <div class="alert alert-success">
                Here's a summary:
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>Fields</th>
                                    <th>Responses</th>
                                </tr>
                            </thead>
                            <tbody style="font-size: small;">
                                <tr>
                                    <td>Name:</td>
                                    <td><?php echo e($user->name); ?></td>
                                </tr>
                                <tr>
                                    <td>Email Address:</td>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <?php if($user->phone): ?>
                                <tr>
                                    <td>Phone:</td>
                                    <td><?php echo e($user->phone); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($response->form_question->question); ?>:</td>
                                    <td><?php echo e($response->response); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div> <!-- END: .modal__content -->
        </div> <!-- END: .modal__container -->
    </div> <!-- END: .modal -->
</body>
</html><?php /**PATH D:\wamp64\www\EkizoneApps\CustomerFeedBackSystem\resources\views/feedback/emails/summary.blade.php ENDPATH**/ ?>