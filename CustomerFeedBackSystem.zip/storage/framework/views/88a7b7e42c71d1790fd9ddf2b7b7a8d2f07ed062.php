<?php $__env->startSection('title'); ?> 
Request Feedback Form
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('feedback.layouts.partials.passwordchecker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="modal__content">
    <h4 class="text-center">Request Feedback</h4>
    <hr>
    <?php if(isset($success)): ?>
    <div class="alert alert-success">
        Your Feedback request mail has been sent successfully!
    </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('feedback.sendrequest')); ?>">
    <?php echo csrf_field(); ?>
    <ul class="form-list">
        <li class="form-list__row">
        <label>Recipient Email Address:</label>
        <input type="email" name="email" required placeholder="Enter Email address"/><br><br>
        <label>Message to Recipient:</label>
        <textarea name="message" cols="30" rows="10"><?php echo $message; ?></textarea>
        </li>
        <li>
        <button type="submit" class="button">Send</button>
        </li>
    </ul>
    </form>
    <?php echo $__env->make('feedback.layouts.partials.adminmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('feedback.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\EkizoneApps\CustomerFeedBackSystem\resources\views/feedback/admin/request.blade.php ENDPATH**/ ?>