<?php $__env->startSection('title'); ?> 
User Feedback Form
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="modal__content">
    <h4 class="text-center">Customer Feedback Form</h4>
    <hr>
    <form method="POST" action="<?php echo e(route('feedback.send')); ?>">
    <?php echo csrf_field(); ?>
    <ul class="form-list">
        <li class="form-list__row">
        <label>Name:</label>
        <input type="text" name="name" required="" />
        </li>
        <li class="form-list__row form-list__row--inline">
        <div>
            <label>Your Info:</label>
            <div class="form-list__input-inline">
            <input type="email" name="email" required="" placeholder="Email" />
            <input type="text" name="phone" placeholder="Phone" minlength="5" maxlength="15" />
            </div>
        </div>
        </li>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="form-list__row">
        <label style="color:brown"><?php echo e($sdata->question); ?>:</label>
        <input type="hidden" name="data[<?php echo e($sdata->id); ?>][question]" value="<?php echo e($sdata->id); ?>">
        <div class="range-field">
        <input type="<?php echo e($sdata->response_type->field_type); ?>" name="data[<?php echo e($sdata->id); ?>][response]" <?php if($sdata->response_type_id == 11): ?> min="1" max="10" <?php endif; ?> <?php if($sdata->required == 1): ?> required <?php endif; ?> <?php if($sdata->response_type_id == 11): ?> id="start" <?php endif; ?> <?php if($sdata->required == 1): ?> required <?php endif; ?> />
        </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li>
        <button type="submit" class="button">Submit</button>
        </li>
    </ul>
    </form>
</div> <!-- END: .modal__content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
$(document).ready(function() {
  $("#start").range();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('feedback.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\EkizoneApps\CustomerFeedBackSystem\resources\views/feedback/form.blade.php ENDPATH**/ ?>