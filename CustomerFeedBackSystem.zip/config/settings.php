<?php

return [
    //password to match to gain access to specific area of the site
    'require_pass' => env('REQUIRE_PASS_STRING', '123456') 
];
