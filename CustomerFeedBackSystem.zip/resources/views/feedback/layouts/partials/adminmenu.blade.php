<div class="small text-center">
    <a href="{{route('feedback.request')}}">Request Form</a> &nbsp;|&nbsp; <a href="{{route('responses.index')}}">All Feedbacks</a>&nbsp;|&nbsp; <a href="{{route('feedback.form')}}">User Survey Form</a>
</div>