<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FormResponseUserInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('form_responses_user_infos')
        ->insert([
            ['session_code' => 'AA2020123', 'email' => 'jokoh@example.com', 'name' => 'Jim Ok', 'created_at' => Carbon::now()]
        ]);
    }
}
